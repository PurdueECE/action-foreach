def getStreaks(sequence, letters):
    print("hi")
    final_list = []
    
    count = 1
    #length = len(sequence)
    comp = []
    while count < len(sequence):
        if sequence[count-1] == sequence[count]:
            count = count + 1
        else:
            comp.append(sequence[:count])
            sequence = sequence[count:]
            count = 1
    comp.append(sequence)
    for i in range(len(comp)):
        str_val = comp[i]
        letter_comp = str_val[0]
        if letter_comp in letters:
            final_list.append(str_val)
    return final_list

if __name__ == " __main__ " :
    print("hi")
    sequence = "AAASSSSSSAPPPSSPPBBCCCSSS"
    z = getStreaks(sequence,"SAQT")
    
    print( z )