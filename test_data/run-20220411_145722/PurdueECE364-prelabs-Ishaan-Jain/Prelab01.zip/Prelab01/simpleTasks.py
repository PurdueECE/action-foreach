# ######################################################
# Author : Ishaan Jain
# email :  jain343@purdue.edu
# ID : ee364b04
# Date : 01/16/22
# ######################################################
import os # List of module import statements
import sys # Each one on a line
# ######################################################
# No Module - Level Variables or Statements !
# ONLY FUNCTIONS BEYOND THIS POINT !
# ######################################################
def writePyramids(filePath, baseSize, count, char):                                
    f = open(filePath,'w')   
    for aj in range(count):
        k = baseSize-1
        for i in range (baseSize):
            for j in range (k):
                f.write(" ")
            k = k - 1
            for jl in range (i - 1):
                f.write(char)    
                f.write("")                  
            f.write(" ")                                      
            f.write("\n") 
    f.close()                              
            
def getStreaks(sequence, letters):
    final_list = []
    
    count = 1
    #length = len(sequence)
    comp = []
    while count < len(sequence):
        if sequence[count-1] == sequence[count]:
            count = count + 1
        else:
            comp.append(sequence[:count])
            sequence = sequence[count:]
            count = 1
    comp.append(sequence)
    for i in range(len(comp)):
        str_val = comp[i]
        letter_comp = str_val[0]
        if letter_comp in letters:
            final_list.append(str_val)
    return final_list
# This block is optional and can be used for testing .
# We will NOT look into its content .
# ######################################################

